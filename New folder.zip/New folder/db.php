<?php
// db.php - MySQL database connection

$host = "localhost"; // or 127.0.0.1
$user = "root"; // Default username for XAMPP
$password = ""; // Default password is empty
$dbname = "apna_lakki_foods";

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
