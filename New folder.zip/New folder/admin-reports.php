<?php
// admin-reports.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin-login.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "apna_lakki_foods");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total sales
$salesQuery = "SELECT SUM(total_price) AS total_sales FROM orders WHERE status = 'Delivered'";
$salesResult = $conn->query($salesQuery);
$salesRow = $salesResult->fetch_assoc();
$totalSales = $salesRow['total_sales'] ?? 0;

// Fetch total orders
$orderQuery = "SELECT COUNT(*) AS total_orders FROM orders";
$orderResult = $conn->query($orderQuery);
$orderRow = $orderResult->fetch_assoc();
$totalOrders = $orderRow['total_orders'] ?? 0;

// Fetch top 5 selling items
$topItemsQuery = "
    SELECT food_name, COUNT(*) AS count 
    FROM order_items 
    GROUP BY food_name 
    ORDER BY count DESC 
    LIMIT 5
";
$topItemsResult = $conn->query($topItemsQuery);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Reports - Apna Lakki Foods</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fff7e6;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 40px;
        }
        h1 {
            color: #cc0000;
        }
        .card {
            background: #fff;
            border-left: 5px solid #cc0000;
            margin: 20px 0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ddd;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
        }
        table th, table td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }
        table th {
            background: #cc0000;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 Admin Reports</h1>

        <div class="card">
            <h2>Total Sales: <span style="color:green;">Rs. <?= number_format($totalSales) ?></span></h2>
            <h3>Total Orders: <?= $totalOrders ?></h3>
        </div>

        <div class="card">
            <h2>Top 5 Selling Items</h2>
            <table>
                <tr>
                    <th>Food Item</th>
                    <th>Number of Orders</th>
                </tr>
                <?php while($item = $topItemsResult->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($item['food_name']) ?></td>
                    <td><?= $item['count'] ?></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>
</html>
